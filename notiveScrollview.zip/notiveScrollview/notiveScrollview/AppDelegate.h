//
//  AppDelegate.h
//  notiveScrollview
//
//  Created by 何云东 on 2019/4/26.
//  Copyright © 2019 hd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

