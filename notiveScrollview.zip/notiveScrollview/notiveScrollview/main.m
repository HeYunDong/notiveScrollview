//
//  main.m
//  notiveScrollview
//
//  Created by 何云东 on 2019/4/26.
//  Copyright © 2019 hd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
