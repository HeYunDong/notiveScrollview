//
//  HomeNoticeScrollView.h
//  testdemo
//
//  Created by 何云东 on 2019/4/26.
//  Copyright © 2019 何云东. All rights reserved.
//
#import <UIKit/UIKit.h>


typedef void(^NoticesClickBlock)(NSInteger index,NSString *content);
@interface HomeNoticeScrollView : UIView
/// 滚动文字数组
@property (nonatomic, strong) NSArray *contents;

/// 文字停留时长，默认5S
@property (nonatomic, assign) NSTimeInterval timeInterval;

/// 文字滚动时长，默认0.3S
@property (nonatomic, assign) NSTimeInterval scrollTimeInterval;
@property (nonatomic, copy) NoticesClickBlock noticesBlock;
@end
