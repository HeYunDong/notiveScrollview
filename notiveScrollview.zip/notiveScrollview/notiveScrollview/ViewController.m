//
//  ViewController.m
//  notiveScrollview
//
//  Created by 何云东 on 2019/4/26.
//  Copyright © 2019 hd. All rights reserved.
//

#import "ViewController.h"
#import "HomeNoticeScrollView.h"
@interface ViewController ()

@property(nonatomic,strong)HomeNoticeScrollView * homeNoticeView;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self creatnsView];
}
-(void)creatnsView{
    
    _homeNoticeView = [[HomeNoticeScrollView alloc] initWithFrame:CGRectMake(100, 300, 300, 30)];
    _homeNoticeView.backgroundColor = UIColor.grayColor;
    [self.view addSubview:_homeNoticeView];
    _homeNoticeView.noticesBlock = ^(NSInteger index, NSString *content) {
        NSLog(@"%zd---,%@",index,content);
    };
    //滚动内容
    NSArray * contentArray = @[@"test1",@"test2",@"test3",@"test4"];
    _homeNoticeView.contents = contentArray;
    
}



@end
